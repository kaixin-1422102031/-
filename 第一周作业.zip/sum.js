const express=require('express')
const app=express()

// const parser=require('body-parser')
// app.use(parser.urlencoded({extended:false}))

// const router=require('./index')
// app.use(router)
// app.set("views",__dirname+"/views")
 app.set('view engine','ejs')
// app.engine('html',ejs.__express)
// app.set('view engine','html')

//app.engine('html',require('express-art-template'))

// app.set('view engine','html')
// app.set("views",path.join(__dirname,'views'))
// app.engine("html",require('ejs'.renderFile))

app.get('/',function(req,res){
    var number1=req.query.Number1;
    var number2=req.query.Number2;
    var sum=parseInt(number1)+parseInt(number2);
    console.log("相加两数分别为：",number1,number2);
    console.log("两数之和：",sum);
    res.render('index',{
        Numbera: number1,
        Numberb: number2,
        sums:sum,
    })
})
app.listen(8011,()=>{
    console.log('express server running at http://127.0.0.1:8011')
})